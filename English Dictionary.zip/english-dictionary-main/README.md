# english-dictionary
The english dictionary website just simply tells the meaning of any english word.
and also play  meaning  of that word in voice command.
